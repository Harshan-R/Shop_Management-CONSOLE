package Pen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
 
 
public class Main
 
{
	    public static void main(String args[]) throws ClassNotFoundException, SQLException {
	       try {
	    	   Class.forName("com.mysql.cj.jdbc.Driver");
		       Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/herodb","root","password");
		        System.out.println("Connection created");
	       }catch(Exception e) {
	    	   System.out.println("Server down");
	       }
	    }
	}