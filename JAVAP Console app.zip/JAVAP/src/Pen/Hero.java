package Pen;
import java.sql.*;  
import java.util.*;

public class Hero {
    // Declare the connection variable outside of the main method
    public static Connection con;

    public static void main(String[] args) throws ClassNotFoundException {
        try {
            // Establish the connection inside the main method
        	Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/VehicleManagementSystem","root","password");
            System.out.println("Connected to database.");
        } catch (SQLException e) {
            System.out.println("Connection failed.");
            e.printStackTrace();
        }
    }
}
