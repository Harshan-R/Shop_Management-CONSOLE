/**
 * 
 */
/**
 * @author harshan_r
 *
 */
module JAVAP {
	requires java.sql;
	requires itextpdf;
	requires mysql.connector.j;
	requires java.mail;
	requires activation;


	
}